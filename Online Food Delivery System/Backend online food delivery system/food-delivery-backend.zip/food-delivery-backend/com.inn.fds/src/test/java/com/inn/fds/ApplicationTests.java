package com.inn.fds;

import com.inn.fds.POJO.*;
import com.inn.fds.dao.*;
import com.inn.fds.wrapper.RestroWrapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class ApplicationTests {
	@Test
	void ApplicationTests(){

	}







}
